
Le dataset 201902_fordgobike_tripdata est utilisé pour le projet 3 qui est de la visualisation des données. Le dataset contient des informations sur chaque cycliste couvrant le grand San Francisco Bay area.

Ce dataset contient 183412 lignes avec 16 différentes colonnes ou variables. Il y a plus de variables numériques que catégorielles dans le dataset. Le dataset présente quelques valeurs manquantes mais les colonnes concernées ne font pas partie des variables d’intérêt pour le projet.


```python
# import all packages and set plots to be embedded inline
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

%matplotlib inline
```


```python
df=pd.read_csv('201902_fordgobike_tripdata.csv')
```


```python
# high-level overview of data shape and composition
df.shape
```




    (183412, 16)



Les questions auxquelles nous voulons répondre à travers le dataset sont la suivant : 
- Combien de temps prend le voyage moyen? 
-  Quelle est la période qu’a duré le plus long voyage en terme d’heure du jour, jour de la semaine ou mois de l’année? 
- Quelle est la proportion des subscriber et customer? 
- Y a-t-il plus de cyclistes hommes que de femmes?

Pour repondre aux questions posees ci—dessus, les variables suivantes seront utilisees : duration_sec,start_time,end_time,user_type et longitude, latitude, member_gender and user_type.

- 1   **De l’exploration des données, il ressort que la durée du voyage moyen est de 726.08 seconds.**


```python
# descriptive statistics for numeric variables
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>duration_sec</th>
      <th>start_station_id</th>
      <th>start_station_latitude</th>
      <th>start_station_longitude</th>
      <th>end_station_id</th>
      <th>end_station_latitude</th>
      <th>end_station_longitude</th>
      <th>bike_id</th>
      <th>member_birth_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>183412.000000</td>
      <td>183215.000000</td>
      <td>183412.000000</td>
      <td>183412.000000</td>
      <td>183215.000000</td>
      <td>183412.000000</td>
      <td>183412.000000</td>
      <td>183412.000000</td>
      <td>175147.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>726.078435</td>
      <td>138.590427</td>
      <td>37.771223</td>
      <td>-122.352664</td>
      <td>136.249123</td>
      <td>37.771427</td>
      <td>-122.352250</td>
      <td>4472.906375</td>
      <td>1984.806437</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1794.389780</td>
      <td>111.778864</td>
      <td>0.099581</td>
      <td>0.117097</td>
      <td>111.515131</td>
      <td>0.099490</td>
      <td>0.116673</td>
      <td>1664.383394</td>
      <td>10.116689</td>
    </tr>
    <tr>
      <th>min</th>
      <td>61.000000</td>
      <td>3.000000</td>
      <td>37.317298</td>
      <td>-122.453704</td>
      <td>3.000000</td>
      <td>37.317298</td>
      <td>-122.453704</td>
      <td>11.000000</td>
      <td>1878.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>325.000000</td>
      <td>47.000000</td>
      <td>37.770083</td>
      <td>-122.412408</td>
      <td>44.000000</td>
      <td>37.770407</td>
      <td>-122.411726</td>
      <td>3777.000000</td>
      <td>1980.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>514.000000</td>
      <td>104.000000</td>
      <td>37.780760</td>
      <td>-122.398285</td>
      <td>100.000000</td>
      <td>37.781010</td>
      <td>-122.398279</td>
      <td>4958.000000</td>
      <td>1987.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>796.000000</td>
      <td>239.000000</td>
      <td>37.797280</td>
      <td>-122.286533</td>
      <td>235.000000</td>
      <td>37.797320</td>
      <td>-122.288045</td>
      <td>5502.000000</td>
      <td>1992.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>85444.000000</td>
      <td>398.000000</td>
      <td>37.880222</td>
      <td>-121.874119</td>
      <td>398.000000</td>
      <td>37.880222</td>
      <td>-121.874119</td>
      <td>6645.000000</td>
      <td>2001.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# la duree en second de average trip
df.duration_sec.mean()
```




    726.078435434977



- 2  **Le plus long voyage a duré 2 jours (28 février au 01 mars 2019)**


```python
columns=['start_time', 'end_time']
df[columns]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>start_time</th>
      <th>end_time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2019-02-28 17:32:10.1450</td>
      <td>2019-03-01 08:01:55.9750</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2019-02-28 18:53:21.7890</td>
      <td>2019-03-01 06:42:03.0560</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2019-02-28 12:13:13.2180</td>
      <td>2019-03-01 05:24:08.1460</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2019-02-28 17:54:26.0100</td>
      <td>2019-03-01 04:02:36.8420</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2019-02-28 23:54:18.5490</td>
      <td>2019-03-01 00:20:44.0740</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>183407</th>
      <td>2019-02-01 00:04:49.7240</td>
      <td>2019-02-01 00:12:50.0340</td>
    </tr>
    <tr>
      <th>183408</th>
      <td>2019-02-01 00:05:34.7440</td>
      <td>2019-02-01 00:10:48.5020</td>
    </tr>
    <tr>
      <th>183409</th>
      <td>2019-02-01 00:06:05.5490</td>
      <td>2019-02-01 00:08:27.2200</td>
    </tr>
    <tr>
      <th>183410</th>
      <td>2019-02-01 00:05:34.3600</td>
      <td>2019-02-01 00:07:54.2870</td>
    </tr>
    <tr>
      <th>183411</th>
      <td>2019-02-01 00:00:20.6360</td>
      <td>2019-02-01 00:04:52.0580</td>
    </tr>
  </tbody>
</table>
<p>183412 rows × 2 columns</p>
</div>




```python
df.loc[:,['start_time', 'end_time']].max()
```




    start_time    2019-02-28 23:59:18.5480
    end_time      2019-03-01 08:01:55.9750
    dtype: object



- 3  **La proportion des subscribers dépasse largement celle des customers. Les subscribers font 163544 alors que les customers font 19868**


```python
df.user_type.value_counts().to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Subscriber</th>
      <td>163544</td>
    </tr>
    <tr>
      <th>Customer</th>
      <td>19868</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots(figsize = [4,4])

default_color = sb.color_palette()[0]
sb.countplot(data = df, x = 'user_type', color = default_color)
plt.title("Les Types d'Utilisateur")
plt.show()
```


![png](output_15_0.png)


- 4  **Il ressort de la visualisation que les hommes sont plus représentés que les femmes parmi les cyclistes**


```python
df.member_gender.value_counts().to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>member_gender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Male</th>
      <td>130651</td>
    </tr>
    <tr>
      <th>Female</th>
      <td>40844</td>
    </tr>
    <tr>
      <th>Other</th>
      <td>3652</td>
    </tr>
  </tbody>
</table>
</div>




```python
type_counts = df['member_gender'].value_counts()
type_counts
n_pokemon = df['member_gender'].value_counts().sum()
#type_order = df['Male'].value_counts().index
base_color = sb.color_palette()[0]
sb.countplot(data=df, y='member_gender', color=base_color);

# Logique pour imprimer le texte de proportion sur les barres
for i in range (type_counts.shape[0]):
# Rappelez-vous, type_counts contient la fréquence des valeurs uniques dans la colonne « type » par ordre décroissant.
    count = type_counts[i]
# Convertir count en pourcentage, puis en chaîne de caractères
    pct_string = '{:0.1f}'.format(100*count/n_pokemon)
# Imprimer la valeur de la chaîne sur la barre.
    plt.text(count+1, i, pct_string, va='center')
    plt.title("Proportion par sexe")
```


![png](output_18_0.png)


- 5 **La corrélation entre type d’utilisateur et le sexe est projeté ci-dessous.** 
De ce graphe il est à noter qu’autant le nombre de cyclistes hommes dépasse celui de femmes autant nous avons plus de subscriber hommes que de femmes. Cette corrélation représente une exploration bivariée.


```python
plt.figure(figsize = [8, 8])

# subplot 1: gender vs user_type
plt.subplot(3, 1, 1)
sb.countplot(data = df, x = 'member_gender', hue = 'user_type', palette = 'Blues')
plt.title('relationship between user_type and gender')
```




    Text(0.5, 1.0, 'relationship between user_type and gender')




![png](output_20_1.png)



```python
plt.figure(figsize = [8, 8])

# subplot 1: gender vs user_type
plt.subplot(3, 1, 1)
sb.countplot(data = df, x = 'member_gender', hue = 'user_type', palette = 'Blues')
plt.title('relationship between user_type and gender')

# subplot 2: clarity vs. cut
ax = plt.subplot(3, 1, 2)
sb.countplot(data = df, x = 'member_gender', hue = 'bike_share_for_all_trip', palette = 'Greens')
ax.legend(ncol = 2) # re-arrange legend to reduce overlapping
plt.title('relationship between gender and bike_share_for_all_trip')

# subplot 3: clarity vs. color, use different color palette
ax = plt.subplot(3, 1, 3)
sb.countplot(data = df, x = 'user_type', hue = 'bike_share_for_all_trip', palette = 'Oranges')
ax.legend(loc = 1, ncol = 2) # re-arrange legend to remove overlapping
plt.title('relationship between user_type and bike_share_for_all_trip')
plt.show()
```


![png](output_21_0.png)


- 6  **La corrélation des variables numériques est affichée ci-dessous:**


```python
numeric_vars = ['duration_sec', 'start_station_id', 'start_station_latitude', 'start_station_longitude', 'end_station_id', 'end_station_latitude', 'end_station_longitude', 'bike_id', 'member_birth_year']
categoric_vars = ['end_station_name','start_station_name','user_type','member_gender','bike_share_for_all_trip']
```


```python
# correlation plot
plt.figure(figsize = [8, 5])
sb.heatmap(df[numeric_vars].corr(), annot = True, fmt = '.3f',
           cmap = 'vlag_r', center = 0)
plt.show()
```


![png](output_24_0.png)


- 7  **Le PairGrid des variables numériques est le suivant. Il représente l’exploration multivariée**


```python
# plot matrix: sample 300 bike riding so that plots are clearer and they render faster
samples = np.random.choice(df.shape[0], 300, replace = False)
bike_samp = df.loc[samples,:]

g = sb.PairGrid(data = bike_samp, vars = numeric_vars)
g = g.map_diag(plt.hist, bins = 20);
g.map_offdiag(plt.scatter)
```

    C:\Users\Dell\Anaconda3\lib\site-packages\numpy\lib\histograms.py:824: RuntimeWarning: invalid value encountered in greater_equal
      keep = (tmp_a >= first_edge)
    C:\Users\Dell\Anaconda3\lib\site-packages\numpy\lib\histograms.py:825: RuntimeWarning: invalid value encountered in less_equal
      keep &= (tmp_a <= last_edge)
    




    <seaborn.axisgrid.PairGrid at 0x196ce0d3358>




![png](output_26_2.png)



```python

```
